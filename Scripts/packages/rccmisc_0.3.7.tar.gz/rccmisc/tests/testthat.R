library(testthat)
library(rccmisc)

test_check("rccmisc")
